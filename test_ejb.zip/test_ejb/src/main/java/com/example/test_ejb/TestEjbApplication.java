package com.example.test_ejb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestEjbApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestEjbApplication.class, args);
	}
}
